<h3 class="text-center">About Us</h3>
<hr>
<div>
    <?php include("about_us.html") ?>
</div>