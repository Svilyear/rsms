<div class="card card-outline card-primary">
	<div class="card-header">
	<h3 class="card-title">Pending Repair List</h3>

    <br>
   
<div class="dropdown"> 
    <div class="card-tools">
        <br>
    <button style="width: 100px; border:1px solid grey" type="button" class="btn btn-flat btn-default btn-sm dropdown-toggle dropdown-icon" data-toggle="dropdown">
   SELECT
        <span class="sr-only">Toggle Dropdown</span>
    </button>
    <div class="dropdown-menu">
        <a class="dropdown-item" href="./?page=repairs/pending">Pending Repair</a>
        <a class="dropdown-item" href="./?page=repairs/approved">Approved Repair</a>
        <a class="dropdown-item" href="./?page=repairs/in_progress">In-Progress Repair</a>
        <a class="dropdown-item" href="./?page=repairs/in_checking">In-Checking Repair</a>
		<a class="dropdown-item" href="./?page=repairs/done">Done Repair</a>
		<a class="dropdown-item" href="./?page=repairs/cancelled">Cancelled Repair</a>
		</div>
    </div>
</div>

    <div class="card-body">
        <div class="container-fluid">
            <table class="table table-hover table-striped table-bordered">
                <colgroup>
                    <col width="5%">
                    <col width="20%">
                    <col width="20%">
                    <col width="25%">
                    <col width="20%">
                    <col width="10%">
                </colgroup>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Date Created</th>
                        <th>Code</th>
                        <th>Client</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                        $i = 1;
                        // Set up status filter

                        $statusFilter = 0;

                        // Modify the query based on the selected status
                        $query = "SELECT r.*, CONCAT(c.lastname, ', ', c.firstname, ' ', c.middlename) as client 
                        FROM `repair_list` r 
                        INNER JOIN client_list c ON r.client_id = c.id 
                        WHERE r.status = $statusFilter 
                        ORDER BY unix_timestamp(r.`date_created`) DESC";                       $qry = $conn->query($query);

                        while($row = $qry->fetch_assoc()):
                    ?>
                        <tr>
                            <td class="text-center"><?php echo $i++; ?></td>
                            <td><?php echo date("Y-m-d H:i", strtotime($row['date_created'])); ?></td>
                            <td><?php echo ($row['code']); ?></td>
                            <td><p class="truncate-1"><?php echo ucwords($row['client']); ?></p></td>
                            <td class="text-center">
                                <?php 
                                    switch ($row['status']){
                                        case 0:
                                            echo '<span class="rounded-pill badge badge-secondary">Pending</span>';
                                            break;
                                        case 1:
                                            echo '<span class="rounded-pill badge badge-primary">Approved</span>';
                                            break;
                                        case 2:
                                            echo '<span class="rounded-pill badge badge-info">In-Progress</span>';
                                            break;
                                        case 3:
                                            echo '<span class="rounded-pill badge badge-warning">Checking</span>';
                                            break;
                                        case 4:
                                            echo '<span class="rounded-pill badge badge-success">Done</span>';
                                            break;
                                        case 5:
                                            echo '<span class="rounded-pill badge badge-danger">Cancelled</span>';
                                            break;
                                    }
                                ?>
                            </td>
                            <td align="center">
                                 <button type="button" class="btn btn-flat btn-default btn-sm dropdown-toggle dropdown-icon" data-toggle="dropdown">
                                    Action
                                    <span class="sr-only">Toggle Dropdown</span>
                                </button>
                                <div class="dropdown-menu" role="menu">
                                    <a class="dropdown-item" href="./?page=repairs/view_details&id=<?php echo $row['id']; ?>" data-id=""><span class="fa fa-window-restore text-gray"></span> View</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="./?page=repairs/manage_repair&id=<?php echo $row['id']; ?>" data-id="<?php echo $row['id']; ?>"><span class="fa fa-edit text-primary"></span> Edit</a>
                                    <div class="dropdown-divider"></div>
                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
    $(document).ready(function(){
        $('.table td,.table th').addClass('py-1 px-2 align-middle')
        $('.table').dataTable({
            columnDefs: [
                { orderable: false, targets: 5 }
            ],
        });
    });
</script>
