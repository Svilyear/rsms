<?php
// Initialize total revenue
$total_revenue = 0;

// Prepare query to get services
$stmt = $conn->prepare("SELECT `date_created`, `code`, `total_amount` FROM `repair_list` WHERE payment_status = 1 ORDER BY `date_created` ASC");
$stmt->execute();
$result = $stmt->get_result();

if ($result === false) {
    error_log("Error in query: " . $stmt->error);
    die("Error fetching data.");
}

// Prepare data for display
$services = [];
while ($row = $result->fetch_assoc()) {
    $total_revenue += $row['total_amount'];
    $services[] = $row; // Store each service for later display
}

// Prepare query to get daily revenue
$daily_stmt = $conn->prepare("
    SELECT DATE(`date_created`) AS `date`, SUM(`total_amount`) AS `daily_total`
    FROM `repair_list`
    WHERE `payment_status` = 1
    GROUP BY `date`
    ORDER BY `date` ASC
");
$daily_stmt->execute();
$daily_result = $daily_stmt->get_result();

$daily_revenues = [];
while ($daily_row = $daily_result->fetch_assoc()) {
    $daily_revenues[] = $daily_row; // Store daily revenue for later display
}
?>

<style>
    .total-revenue {
        font-weight: bold;
        font-size: 1.9em; /* Larger font size */
        text-align: right; /* Align to the right */
        color: green; /* Set color to green */
    }
    th {
        text-align: center;
        color: red;
    }
</style>

<div class="card card-outline card-primary">
    <div class="card-header">
        
        <h3 class="card-title">Total Earnings</h3>
        
        <br>
        <div class="dropdown">
            <button type="button" class="btn btn-flat btn-default btn-sm dropdown-toggle dropdown-icon" data-toggle="dropdown">
              
                Select Earnings
                <span class="sr-only">Toggle Dropdown</span>
            </button>
            <div class="dropdown-menu">
                <a class="dropdown-item" href="#">Daily</a>
               <a class="dropdown-item" href="<?php echo base_url ?>admin/?page=user/weekly">Weekly</a>
                <a class="dropdown-item" href="<?php echo base_url ?>admin/?page=user/monthly">Monthly</a>
                <a class="dropdown-item" href="<?php echo base_url ?>admin/?page=user/yearly">Yearly</a>
            </div>
        </div>
    </div>

    

    <div class="card-body">
        <div class="container-fluid">
      
            <!-- Daily Revenue Section -->
            <h4>Daily Revenue Summary</h4>


            <table class="table table-hover table-striped table-bordered">
          
                <thead>
                    <tr>
                        <td colspan="4" class="total-revenue">
                            Total Revenue: <?php echo number_format($total_revenue, 2); ?>
                        </td>
                    </tr>
                <thead>
                    <tr>
                        <th>Date</th>
                       <th>Daily Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    if (empty($daily_revenues)) {
                        echo "<tr><td colspan='2'>No daily revenue found.</td></tr>";
                    } else {
                        foreach ($daily_revenues as $daily): 
                    ?>
                    <tr>
                        <td><?php echo date("Y-m-d", strtotime($daily['date'])); ?></td>
                     
                        <td class="text-center"><?php echo number_format($daily['daily_total'], 2); ?></td>
                    </tr>
                    <?php 
                        endforeach; 
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>