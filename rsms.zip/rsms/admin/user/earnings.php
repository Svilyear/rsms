<?php
// Initialize total revenue
$total_revenue = 0;

// Prepare query to get services
$stmt = $conn->prepare("SELECT * FROM `repair_list` WHERE  `payment_status` = 1 ORDER BY `date_created` ASC");
$stmt->execute();
$result = $stmt->get_result();

if ($result === false) {
    error_log("Error in query: " . $conn->error);
    die("Error fetching data.");
}

// Calculate total revenue
while ($row = $result->fetch_assoc()) {
    $total_revenue += $row['total_amount'];
}
?>

<style>
    .img-thumb-path {
        width: 100px;
        height: 80px;
        object-fit: scale-down;
        object-position: center center;
    }
    .total-revenue {
        font-weight: bold;
        font-size: 1.9em; /* Larger font size */
        text-align: right; /* Align to the right */
        color: green; /* Set color to green */
    }
    th {
        text-align: center;
        color: red;
    }
</style>

<div class="card card-outline card-primary">
    <div class="card-header">
        <h3 class="card-title">Total Earnings</h3>
        <br>
        <div class="dropdown">
            <button type="button" class="btn btn-flat btn-default btn-sm dropdown-toggle dropdown-icon" data-toggle="dropdown">
              
                Select Earnings
                <span class="sr-only">Toggle Dropdown</span>
            </button>
            <div class="dropdown-menu">
                <a class="dropdown-item" href="./?page=user/daily">Daily</a>
                <a class="dropdown-item" href="./?page=user/weekly">Weekly</a>
                <a class="dropdown-item" href="./?page=user/monthly">Monthly</a>
                <a class="dropdown-item" href="./?page=user/yearly">Yearly</a>
            </div>
        </div>
    </div>

    <div class="card-body">
        <div class="container-fluid">
            <table class="table table-hover table-striped table-bordered">
                <colgroup>
                    <col width="5%">
                    <col width="15%">
                    <col width="20%">
                    <col width="10%">
                </colgroup>
                <thead>
                    <tr>
                        <td colspan="4" class="total-revenue">
                            Total Revenue: <?php echo number_format($total_revenue, 2); ?>
                        </td>
                    </tr>
                    <tr>
                        <th>#</th>
                        <th>Date Created</th>
                        <th>Service</th>
                        <th>Cost</th>
                    </tr>
                </thead>
                <tbody>
                     <?php 
                    $i = 1;
                   // $stmt = $conn->prepare("SELECT * FROM `repair_list` WHERE  `payment_status` = 1 ORDER BY `date_created` ASC");
                    $stmt->execute();
                    $result = $stmt->get_result();

                    if ($result === false) {
                        echo "<tr><td colspan='4'>Error fetching services.</td></tr>";
                    } else {
                        while ($row = $result->fetch_assoc()): 
                    ?> 
                    <tr>
                        <td class="text-center"><?php echo $i++; ?></td>
                        <td><?php echo date("Y-m-d H:i", strtotime($row['date_created'])); ?></td>
                        <td><?php echo ucwords($row['code']); ?></td>
                        <td class="text-center"><?php echo number_format($row['total_amount'], 2); ?></td>
                    </tr>
                    <?php 
                        endwhile; 
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
