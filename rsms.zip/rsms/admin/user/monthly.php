<?php
// Initialize total revenue
$total_revenue = 0;

// Prepare query to get services
$stmt = $conn->prepare("SELECT `date_created`, `code`, `total_amount` FROM `repair_list` WHERE payment_status = 1 ORDER BY `date_created` ASC");
$stmt->execute();
$result = $stmt->get_result();

if ($result === false) {
    error_log("Error in query: " . $stmt->error);
    die("Error fetching data.");
}

// Prepare data for display
$services = [];
while ($row = $result->fetch_assoc()) {
    $total_revenue += $row['total_amount'];
    $services[] = $row; // Store each service for later display
}

// Prepare query to get monthly revenue
$monthly_stmt = $conn->prepare("
    SELECT DATE_FORMAT(`date_created`, '%Y-%m') AS `month`, SUM(`total_amount`) AS `monthly_total`
    FROM `repair_list`
    WHERE `payment_status` = 1
    GROUP BY `month`
    ORDER BY `month` ASC
");
$monthly_stmt->execute();
$monthly_result = $monthly_stmt->get_result();

$monthly_revenues = [];
while ($monthly_row = $monthly_result->fetch_assoc()) {
    $monthly_revenues[] = $monthly_row; // Store monthly revenue for later display
}
?>

<style>
    .total-revenue {
        font-weight: bold;
        font-size: 1.9em; /* Larger font size */
        text-align: right; /* Align to the right */
        color: green; /* Set color to green */
    }
    th {
        text-align: center;
        color: red;
    }
</style>

<div class="card card-outline card-primary">
    <div class="card-header">
        <h3 class="card-title">Total Earnings</h3>
        <br>
        <div class="dropdown">
            <button type="button" class="btn btn-flat btn-default btn-sm dropdown-toggle dropdown-icon" data-toggle="dropdown">
                Select Earnings
                <span class="sr-only">Toggle Dropdown</span>
            </button>
            <div class="dropdown-menu">
                <a class="dropdown-item" href="<?php echo base_url ?>admin/?page=user/daily">Daily</a>
                <a class="dropdown-item" href="<?php echo base_url ?>admin/?page=user/weekly">Weekly</a>
                <a class="dropdown-item" href="<?php echo base_url ?>admin/?page=user/monthly">Monthly</a>
                <a class="dropdown-item" href="<?php echo base_url ?>admin/?page=user/yearly">Yearly</a>
            </div>
        </div>
    </div>

    <div class="card-body">
        <div class="container-fluid">
            <!-- Monthly Revenue Section -->
            <h4>Monthly Revenue Summary</h4>
            <table class="table table-hover table-striped table-bordered">
                <thead>
                    <tr>
                        <td colspan="3" class="total-revenue">
                            Total Revenue: <?php echo number_format($total_revenue, 2); ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Month</th>
                        <th>Monthly Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    if (empty($monthly_revenues)) {
                        echo "<tr><td colspan='2'>No monthly revenue found.</td></tr>";
                    } else {
                        foreach ($monthly_revenues as $monthly): 
                            // Format month and year
                            $monthYear = date("F Y", strtotime($monthly['month']));
                    ?>
                    <tr>
                        <td><?php echo $monthYear; ?></td>
                        <td class="text-center"><?php echo number_format($monthly['monthly_total'], 2); ?></td>
                    </tr>
                    <?php 
                        endforeach; 
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
