<?php
// Initialize total revenue
$total_revenue = 0;

// Query to get services
$qry = $conn->query("SELECT * from `service_list` where delete_flag = 0 order by `service` asc ");

// Calculate total revenue
while ($row = $qry->fetch_assoc()) {
    $total_revenue += $row['cost']; // Calculate total revenue
}
?>

<style>
    .img-thumb-path {
        width: 100px;
        height: 80px;
        object-fit: scale-down;
        object-position: center center;
    }
    .total-revenue {
        font-weight: bold;
        font-size: 1.9em; /* Larger font size */
        text-align: right; /* Align to the right */
        color: green; /* Set color to green */
    }
</style>
<div class="card card-outline card-primary rounded-0 shadow">
    <div class="card-header">
        <!-- <h3 class="card-title">REVENUE</h3> -->
        <div class="total-revenue">
            Total Revenue: <?php echo number_format($total_revenue, 2); ?> <!-- Display total revenue -->
        </div>
        <!-- <div class="card-tools">
            <a href="javascript:void(0)" id="create_new" class="btn btn-flat btn-sm btn-primary"><span class="fas fa-plus"></span> Add New Service</a>
        </div> -->
    </div>
    <div class="card-body">
        <div class="container-fluid">
            <table class="table table-hover table-striped">
                <colgroup>
                    <col width="5%">
                    <col width="20%">
                    <col width="20%">
                    <col width="10%">
                </colgroup>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Date Created</th>
                        <th>Service</th>
                        <th>Cost</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                        $i = 1;
                        // Reset query pointer to fetch again for the table
                        $qry->data_seek(0);
                        while ($row = $qry->fetch_assoc()):
                    ?>
                        <tr>
                            <td class="text-center"><?php echo $i++; ?></td>
                            <td><?php echo date("Y-m-d H:i", strtotime($row['date_created'])); ?></td>
                            <td><?php echo ucwords($row['service']); ?></td>
                            <td class="text-right"><?php echo number_format($row['cost'], 2); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        $('#create_new').click(function() {
            uni_modal("Add New Service", "services/manage_service.php");
        });
        $('.table td, .table th').addClass('py-1 px-2 align-middle');
        $('.table').dataTable({
            columnDefs: [
                { orderable: false, targets: 3 } // Updated to match column indices
            ],
        });
    });

    function delete_service($id) {
        start_loader();
        $.ajax({
            url: _base_url_ + "classes/Master.php?f=delete_service",
            method: "POST",
            data: { id: $id },
            dataType: "json",
            error: err => {
                console.log(err);
                alert_toast("An error occurred.", 'error');
                end_loader();
            },
            success: function(resp) {
                if (typeof resp == 'object' && resp.status == 'success') {
                    location.reload();
                } else {
                    alert_toast("An error occurred.", 'error');
                    end_loader();
                }
            }
        });
    }
</script>
