<?php
// Initialize total revenue
$total_revenue = 0;

// Prepare query to get services
$stmt = $conn->prepare("SELECT `date_created`, `code`, `total_amount` FROM `repair_list` WHERE payment_status = 1 ORDER BY `date_created` ASC");
$stmt->execute();
$result = $stmt->get_result();

if ($result === false) {
    error_log("Error in query: " . $stmt->error);
    die("Error fetching data.");
}

// Prepare data for display
$services = [];
while ($row = $result->fetch_assoc()) {
    $total_revenue += $row['total_amount'];
    $services[] = $row; // Store each service for later display
}

// Prepare query to get weekly revenue
$weekly_stmt = $conn->prepare("
    SELECT YEARWEEK(`date_created`, 1) AS `week`, SUM(`total_amount`) AS `weekly_total`
    FROM `repair_list`
    WHERE `payment_status` = 1
    GROUP BY `week`
    ORDER BY `week` ASC
");
$weekly_stmt->execute();
$weekly_result = $weekly_stmt->get_result();

$weekly_revenues = [];
while ($weekly_row = $weekly_result->fetch_assoc()) {
    $weekly_revenues[] = $weekly_row; // Store weekly revenue for later display
}
?>

<style>
    .total-revenue {
        font-weight: bold;
        font-size: 1.9em; /* Larger font size */
        text-align: right; /* Align to the right */
        color: green; /* Set color to green */
    }
    th {
        text-align: center;
        color: red;
    }
</style>

<div class="card card-outline card-primary">
    <div class="card-header">
        <h3 class="card-title">Total Earnings</h3>
        <br>
        <div class="dropdown">
            <button type="button" class="btn btn-flat btn-default btn-sm dropdown-toggle dropdown-icon" data-toggle="dropdown">
                Select Earnings
                <span class="sr-only">Toggle Dropdown</span>
            </button>
            <div class="dropdown-menu">
               <a class="dropdown-item" href="<?php echo base_url ?>admin/?page=user/daily">Daily</a>
              <a class="dropdown-item" href="<?php echo base_url ?>admin/?page=user/weekly">Weekly</a>
               <a class="dropdown-item" href="<?php echo base_url ?>admin/?page=user/monthly">Monthly</a>
                <a class="dropdown-item" href="<?php echo base_url ?>admin/?page=user/yearly">Yearly</a>
            </div>
        </div>
    </div>

    <div class="card-body">
        <div class="container-fluid">
            <!-- Weekly Revenue Section -->
            <h4>Weekly Revenue Summary</h4>
            <table class="table table-hover table-striped table-bordered">
                <thead>
                    <tr>
                        <td colspan="3" class="total-revenue">
                            Total Revenue: <?php echo number_format($total_revenue, 2); ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Week</th>
                        <th>Weekly Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    if (empty($weekly_revenues)) {
                        echo "<tr><td colspan='2'>No weekly revenue found.</td></tr>";
                    } else {
                        foreach ($weekly_revenues as $weekly): 
                            // Extract week number and year
                            $week_number = $weekly['week'];
                            $year = intval($week_number / 100); // Extract year
                            $week = $week_number % 100; // Extract week number
                    ?>
                    <tr>
                        <td><?php echo "Week $week of $year"; ?></td>
                        <td class="text-center"><?php echo number_format($weekly['weekly_total'], 2); ?></td>
                    </tr>
                    <?php 
                        endforeach; 
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
